package esercizio11;

public class Rombo {
    private double d1; // Diagonale maggiore
    private double d2; // Diagonale minore

    public Rombo(double d1, double d2) {
        this.d1 = d1;
        this.d2 = d2;
    }

    public double calcolaArea() {
        return (d1 * d2) / 2;
    }

    public double calcolaPerimetro(double lato) {
        return 4 * lato;
    }
}

