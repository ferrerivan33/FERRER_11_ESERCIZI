package esercizio7;


public class ContatoreModuloNPasso {
    private int valore;
    private int modulo;
    private int passo;

    public ContatoreModuloNPasso(int modulo, int passo) {
        this.valore = 0;
        this.modulo = modulo;
        this.passo = passo;
    }

    public void incrementa() {
        valore = (valore + passo) % modulo;
    }

    public void decrementa() {
        valore = (valore - passo + modulo) % modulo;
    }

    public int getValore() {
        return valore;
    }
}

