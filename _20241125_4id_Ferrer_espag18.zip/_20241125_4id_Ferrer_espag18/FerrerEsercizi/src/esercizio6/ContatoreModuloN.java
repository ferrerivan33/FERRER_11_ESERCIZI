package esercizio6;

public class ContatoreModuloN {
    private int valore;
    private int modulo;

    public ContatoreModuloN(int modulo) {
        this.valore = 0;
        this.modulo = modulo;
    }

    public void incrementa() {
        valore = (valore + 1) % modulo;
    }

    public void decrementa() {
        valore = (valore - 1 + modulo) % modulo;
    }

    public int getValore() {
        return valore;
    }
}

