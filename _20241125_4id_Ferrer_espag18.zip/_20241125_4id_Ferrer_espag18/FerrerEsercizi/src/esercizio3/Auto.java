package esercizio3;

public class Auto {
    private String marca;
    private String modello;
    private String targa;
    private int annoImmatricolazione;

    public Auto(String marca, String modello, String targa, int annoImmatricolazione) {
        this.marca = marca;
        this.modello = modello;
        this.targa = targa;
        this.annoImmatricolazione = annoImmatricolazione;
    }

    @Override
    public String toString() {
        return "Auto [Marca=" + marca + ", Modello=" + modello + ", Targa=" + targa + ", Anno Immatricolazione=" + annoImmatricolazione + "]";
    }
}

