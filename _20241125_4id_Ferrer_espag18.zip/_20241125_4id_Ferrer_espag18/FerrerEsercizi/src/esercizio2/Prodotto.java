package esercizio2;

public class Prodotto {
	private String proprietario;
	private String nomeNegozio;

	// Primo costruttore
	public Prodotto(String proprietario) {
		this.proprietario = proprietario;
		this.nomeNegozio = "N/A";
	}

	// Secondo costruttore
	public Prodotto(String proprietario, String nomeNegozio) {
		this.proprietario = proprietario;
		this.nomeNegozio = nomeNegozio;
	}

	@Override
	public String toString() {
		return "Prodotto [Proprietario=" + proprietario + ", Nome Negozio=" + nomeNegozio + "]";
	}
}
