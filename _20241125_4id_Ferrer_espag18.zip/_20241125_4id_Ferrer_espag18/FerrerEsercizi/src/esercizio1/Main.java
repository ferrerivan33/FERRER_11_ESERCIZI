package esercizio1;

public class Main {

	public static void main(String[] args) {
		
		TelefonoCellulare cell = new TelefonoCellulare("Iphone", "Iphone 14", "3893233456");
		
		cell.toString();
	}

}
