package esercizio1;

public class TelefonoCellulare {
    private String marca;
    private String modello;
    private String numero;

    public TelefonoCellulare(String marca, String modello, String numero) {
        this.marca = marca;
        this.modello = modello;
        this.numero = numero;
    }

    public String getMarca() {
        return marca;
    }

    public String getModello() {
        return modello;
    }

    public String getNumero() {
        return numero;
    }

    @Override
    public String toString() {
        return "TelefonoCellulare [Marca=" + marca + ", Modello=" + modello + ", Numero=" + numero + "]";
    }
}

