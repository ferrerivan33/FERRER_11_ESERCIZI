package esercizio4;

public class Studente {
    private String cognome;
    private String nome;
    private String codiceFiscale;
    private String numeroMatricola;

    public Studente(String cognome, String nome, String codiceFiscale, String numeroMatricola) {
        this.cognome = cognome;
        this.nome = nome;
        this.codiceFiscale = codiceFiscale;
        this.numeroMatricola = numeroMatricola;
    }

    @Override
    public String toString() {
        return "Studente [Cognome=" + cognome + ", Nome=" + nome + ", Codice Fiscale=" + codiceFiscale + ", Numero Matricola=" + numeroMatricola + "]";
    }
}

