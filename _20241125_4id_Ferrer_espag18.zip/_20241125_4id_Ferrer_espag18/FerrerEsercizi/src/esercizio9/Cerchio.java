package esercizio9;

public class Cerchio {
    private double xc;
    private double yc;
    private double raggio;

    public Cerchio(double xc, double yc, double raggio) {
        this.xc = xc;
        this.yc = yc;
        this.raggio = raggio;
    }

    public double calcolaArea() {
        return Math.PI * raggio * raggio;
    }

    public double calcolaPerimetro() {
        return 2 * Math.PI * raggio;
    }
}

